package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Branch {

	private JFrame frame;
	private JButton Islamabad_btn;
	private JButton Rwp_btn;

	public Branch() {

		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setForeground(Color.ORANGE);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 396, 300);
		frame.getContentPane().setLayout(null);
		
		JButton Islamabad_btn = new JButton("Isb Branch");
		Islamabad_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Islamabad_btn.setForeground(Color.ORANGE);
		Islamabad_btn.setBackground(Color.BLACK);
		Islamabad_btn.setBounds(67, 35, 242, 79);
		frame.getContentPane().add(Islamabad_btn);
		
		JButton Rwp_btn = new JButton("Rwp Branch");
		Rwp_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Rwp_btn.setForeground(Color.ORANGE);
		Rwp_btn.setBackground(Color.BLACK);
		Rwp_btn.setBounds(67, 146, 242, 79);
		frame.getContentPane().add(Rwp_btn);
		
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Islamabad_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Islamabad_btn){
	        		 frame.dispose();
	        		 PlaceOrder A = new PlaceOrder(1);	 
				 }
			}
		});
		Rwp_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 if (e.getSource()==Rwp_btn){
        		 frame.dispose();
        		 PlaceOrder A = new PlaceOrder(2); 	 
			 }
		}
	});
		
		
	}
}