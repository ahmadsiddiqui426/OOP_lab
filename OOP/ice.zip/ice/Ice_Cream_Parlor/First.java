package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class First {
	private JFrame frame;
	private JButton Admin_btn;
	private JButton Order_btn;

	public First() {

		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.setForeground(Color.ORANGE);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 396, 300);
		frame.getContentPane().setLayout(null);
		
		JButton Admin_btn = new JButton("Admin");
		Admin_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Admin_btn.setForeground(Color.ORANGE);
		Admin_btn.setBackground(Color.BLACK);
		Admin_btn.setBounds(67, 35, 242, 79);
		frame.getContentPane().add(Admin_btn);
		
		JButton Order_btn = new JButton("Place Order");
		Order_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Order_btn.setForeground(Color.ORANGE);
		Order_btn.setBackground(Color.BLACK);
		Order_btn.setBounds(67, 146, 242, 79);
		frame.getContentPane().add(Order_btn);
		
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Admin_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Admin_btn){
	        		 frame.dispose();
	        		 Admin_0 A = new Admin_0();	 
				 }
			}
		});
		Order_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 if (e.getSource()==Order_btn){
        		 frame.dispose();
        	Branch A = new Branch(); 	 
			 }
		}
	});
		
		
	}
}

