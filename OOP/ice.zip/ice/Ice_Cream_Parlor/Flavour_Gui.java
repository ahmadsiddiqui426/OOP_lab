package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Flavour_Gui {
	private JFrame frame;
	private JButton Add_btn;
	private	JButton View_btn;
	private JButton Remove_btn;
	private JButton Back_btn;

	public Flavour_Gui() {

		frame = new JFrame();
		frame.setBackground(Color.BLACK);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JButton Add_btn = new JButton("Add Flavour");
		Add_btn.setForeground(Color.ORANGE);
		Add_btn.setBackground(Color.BLACK);
		Add_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Add_btn.setBounds(109, 48, 201, 53);
		frame.getContentPane().add(Add_btn);
		
		JButton View_btn = new JButton("View Flavour");
		View_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		View_btn.setForeground(Color.ORANGE);
		View_btn.setBackground(Color.BLACK);
		View_btn.setBounds(109, 142, 201, 53);
		frame.getContentPane().add(View_btn);
		
		JButton Remove_btn = new JButton("Remove Flavour");
		Remove_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Remove_btn.setForeground(Color.ORANGE);
		Remove_btn.setBackground(Color.BLACK);
		Remove_btn.setBounds(109, 233, 201, 53);
		frame.getContentPane().add(Remove_btn);
		frame.setBounds(100, 100, 450, 357);
		
		JButton Back_btn = new JButton("Back");
		Back_btn.setForeground(Color.ORANGE);
		Back_btn.setBackground(Color.BLACK);
		Back_btn.setFont(new Font("Tahoma", Font.BOLD, 11));
		Back_btn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(Back_btn);
		frame.setBounds(100, 100, 450, 357);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		
		Back_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Back_btn){
	        		 frame.dispose();
	        		 Admin_1 F = new Admin_1();	 
				 }
			}
		});
		Remove_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Remove_btn){
	        		 frame.dispose();
	        		 Remove_flavour F = new Remove_flavour();	 
				 }
			}
		});
		Add_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Add_btn){
	        		 frame.dispose();
	        		Flavour_st F = new Flavour_st();	 
				 }
			}
		});	
		View_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==View_btn){
	        		 frame.dispose();
	        		 View F = new View();	 
	        		 
				 }
			}
		});	
		
		
		
	}
}
