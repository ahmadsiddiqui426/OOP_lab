package Ice_Cream_Parlor;
import java.util.*;
public class Rawalpindi extends Enchanted{
	public Rawalpindi(){
        super();
    }
	public void readData() {
	super.readData();

        
	}
		public String toString(){
        return(super.toString());
    }
}
