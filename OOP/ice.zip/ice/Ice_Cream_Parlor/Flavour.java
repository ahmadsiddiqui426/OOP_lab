package Ice_Cream_Parlor;
import java.io.Serializable;
import java.util.*;
public class Flavour implements Serializable{
	private String name;
	   private int noOfScoops;
	   
	   public Flavour() {
		   name = null;
		   noOfScoops = 0;
	   }
	   public Flavour(String n, int ns) {
		   name = n;
		   noOfScoops = ns;
	   }
    public String getName(){
        return name;
    }
    public void setName(String n){
        name = n;
    }
    public int getNo_of_Scoops(){
        return noOfScoops;
    }
    public void setNo_of_Scoops(int nu){
    	noOfScoops -= nu;
    }

}