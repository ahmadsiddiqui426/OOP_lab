package Ice_Cream_Parlor;
import java.util.*;
public class Islamabad extends Enchanted{
	public Islamabad(){
        super();
        }
    public void readData(){

    	super.readData();

    }

    public String toString(){
        return(super.toString());
    }

}
