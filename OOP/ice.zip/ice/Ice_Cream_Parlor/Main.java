package Ice_Cream_Parlor;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
	First F = new First();
	}
}
