package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.util.Arrays;

public class PlaceOrder {
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JButton enterbtn;
	private JButton Backbtn;
	private JLabel label;
	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private JLabel label4;
	
	
	
	public PlaceOrder(int branchCode) {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.ORANGE);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("Place Order");
		label.setFont(new Font("Tahoma", Font.BOLD, 18));
		label.setForeground(Color.ORANGE);
		label.setBounds(142, 0, 122, 40);
		frame.getContentPane().add(label);
		
		JLabel label1 = new JLabel("Mango");
		label1.setFont(new Font("Tahoma", Font.BOLD, 15));
		label1.setForeground(Color.ORANGE);
		label1.setBounds(36, 71, 95, 31);
		frame.getContentPane().add(label1);
		
		JLabel label2 = new JLabel("Vanilla");
		label2.setFont(new Font("Tahoma", Font.BOLD, 15));
		label2.setForeground(Color.ORANGE);
		label2.setBounds(36, 129, 95, 31);
		frame.getContentPane().add(label2);
		
		JLabel label3 = new JLabel("Strawberry");
		label3.setFont(new Font("Tahoma", Font.BOLD, 15));
		label3.setForeground(Color.ORANGE);
		label3.setBounds(36, 189, 95, 31);
		frame.getContentPane().add(label3);
		
		JLabel label4 = new JLabel("Chocolate");
		label4.setFont(new Font("Tahoma", Font.BOLD, 15));
		label4.setForeground(Color.ORANGE);
		label4.setBounds(36, 250, 95, 31);
		frame.getContentPane().add(label4);
		
		String [] items = {};
		
		try {
			ObjectInputStream input=new ObjectInputStream(new FileInputStream("Flavour.dat"));
		    while(input != null) {
		        Flavour flv = (Flavour) input.readObject();
		        if(flv.getName().equalsIgnoreCase("Mango") || flv.getName().equalsIgnoreCase("Strawberry") || flv.getName().equalsIgnoreCase("Vanilla") || flv.getName().equalsIgnoreCase("Chocolate")) {
		        	System.out.println();
		        }
		        else {
		        	items = Arrays.copyOf(items, items.length + 1);
			        items[items.length - 1] = flv.getName();
		        }
		        
		    }  
		}
		catch(Exception ex) {
			System.out.println("Exception in Reading" + ex);
		}
		
		JComboBox TempFlavour = new JComboBox(items);
		TempFlavour.setFont(new Font("Tahoma", Font.BOLD, 15));
		TempFlavour.setForeground(Color.ORANGE);
		TempFlavour.setBackground(Color.BLACK);
		TempFlavour.setBounds(36, 307, 95, 22);
		frame.getContentPane().add(TempFlavour);
		
		textField = new JTextField();
		textField.setBounds(267, 76, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(267, 134, 86, 20);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(267, 194, 86, 20);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(267, 255, 86, 20);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(267, 308, 86, 20);
		frame.getContentPane().add(textField_4);
		
		JButton enterbtn = new JButton("Enter");
		enterbtn.setBackground(Color.BLACK);
		enterbtn.setForeground(Color.ORANGE);
		enterbtn.setBounds(159, 396, 89, 23);
		frame.getContentPane().add(enterbtn);
		
		JButton Backbtn = new JButton("Back");
		Backbtn.setForeground(Color.ORANGE);
		Backbtn.setFont(new Font("Tahoma", Font.BOLD, 11));
		Backbtn.setBackground(Color.BLACK);
		Backbtn.setBounds(0, 0, 75, 23);
		frame.getContentPane().add(Backbtn);
		frame.setBounds(100, 100, 427, 481);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Backbtn){
	        		 frame.dispose();
	        		 First F = new First();	 
				 }
			}
		});
		
		
		enterbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==enterbtn){
	        		 int a = Integer.parseInt(textField.getText());
	        		 int b = Integer.parseInt(textField_1.getText());
	        		 int c = Integer.parseInt(textField_2.getText());
	        		 int d = Integer.parseInt(textField_3.getText());
	        		 int q = Integer.parseInt(textField_4.getText());
	        		 int total = (a + b + c + d + q);
	        		 int totalBill = (a + b + c + d + q) * 100;
	        		 JOptionPane.showMessageDialog(null, "Your Total Bill is : " + totalBill);
	        		 
	        		 
	        		 
	        		 if(branchCode == 1) { // Islamabad
	        			 try {
		        	            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Isb.dat"));
		        	                SaleIsb slp = new SaleIsb(total);
		        	                output.writeObject(slp);
		        	                output.close();
		        			}
		        			catch(Exception ex) {
		        				System.out.println("Exception in Writing" + ex);
		        			}
	        		 }
	        		 else{ // Rwp
	        			 try {
		        	            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Rwp.dat"));
		        	                SaleRwp slp = new SaleRwp(total);
		        	                output.writeObject(slp);
		        	                output.close();
		        			}
		        			catch(Exception ex) {
		        				System.out.println("Exception in Writing" + ex);
		        			}
	        		 }
	        		 frame.dispose();
	        		 PlaceOrder ad = new PlaceOrder(branchCode);
				 }
				 }
		});
	
		
		
		
		
		
	}

}

