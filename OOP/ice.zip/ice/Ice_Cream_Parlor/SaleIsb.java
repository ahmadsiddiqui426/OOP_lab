
package Ice_Cream_Parlor;

import java.io.Serializable;

public class SaleIsb implements Serializable {
    private int Scoop_Sold_Isb;
    
    
    public SaleIsb(int isb) {
    	this.Scoop_Sold_Isb = isb;
    }
    
    public int getIsb(){
        return Scoop_Sold_Isb;
    }
    
   
}
