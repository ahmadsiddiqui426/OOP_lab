package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Admin_0 {
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JLabel Label1;
	private JLabel Label2;
	private JButton Button1;
	private JButton Backbtn;
	
	
	
	public Admin_0() {

		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JLabel Label1 = new JLabel("Admin");
		Label1.setForeground(Color.ORANGE);
		Label1.setBackground(Color.BLACK);
		Label1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		Label1.setBounds(170, 11, 130, 34);
		frame.getContentPane().add(Label1);
		
		JLabel Label2 = new JLabel("Username");
		Label2.setFont(new Font("Tahoma", Font.BOLD, 15));
		Label2.setForeground(Color.ORANGE);
		Label2.setBounds(24, 75, 130, 39);
		frame.getContentPane().add(Label2);
		
		JLabel Label3 = new JLabel("Password");
		Label3.setFont(new Font("Tahoma", Font.BOLD, 15));
		Label3.setForeground(Color.ORANGE);
		Label3.setBounds(24, 143, 130, 39);
		frame.getContentPane().add(Label3);
		
		textField = new JTextField();
		textField.setForeground(Color.ORANGE);
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(228, 77, 148, 39);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.ORANGE);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_1.setColumns(10);
		textField_1.setBounds(228, 143, 148, 39);
		frame.getContentPane().add(textField_1);
		
		JButton Button1 = new JButton("Enter");
		Button1.setBackground(Color.BLACK);
		Button1.setForeground(Color.ORANGE);
		Button1.setBounds(155, 227, 114, 23);
		frame.getContentPane().add(Button1);
		
		JButton Backbtn = new JButton("Back");
		Backbtn.setForeground(Color.ORANGE);
		Backbtn.setBackground(Color.BLACK);
		Backbtn.setBounds(0, 0, 78, 23);
		frame.getContentPane().add(Backbtn);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 450, 302);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	
	
		
		Button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Button1){
	        		 if(textField.getText().equals("Admin") && textField_1.getText().equals("1234")) {
	            		 JOptionPane.showMessageDialog(null,"Login Successful");
	            		 frame.dispose();
	            		 Admin_1 F = new Admin_1();
	            	}
	            	else
	            		JOptionPane.showMessageDialog(null,"Invalid Credentials!");
				 }
			}
		});
		
		
		
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Backbtn){
	        		 frame.dispose();
	        		 First F = new First();	 
				 }
			}
		});	
		
	
	
	
	
	}
}