package Ice_Cream_Parlor;

import java.io.Serializable;
import java.util.Scanner;

public  class Employee implements Serializable {    
	    private String Name;
	    private int salary;
	    private String contact;
	    private String cnic;
	    private String address;           
	    
	    public Employee(){
	        this.Name = null;
	        this.salary=0;
	        this.contact = null;
	        this.cnic = null;
	        this.address = null;
	    }
	    
	    public Employee(String name,int salary ,String contact, String cnic, String address){
	        this.Name = name;
	        this.salary=salary;
	        this.contact = contact;
	        this.cnic = cnic;
	        this.address = address;
	    }
	    public String getName(){
	        return Name;
	    }
	    public void setName(String n){
	        Name = n;
	    }
	    public int getSalary(){
	        return salary;
	    }
	    public void setSalary(int s){
	        salary = s;
	    }
	    public String gecontact(){
	        return contact;
	    }
	    public void setcontact(String c){
	        contact = c;
	    }
	    public String getcnic(){
	        return cnic;
	    }
	    public void setcnic(String cn){
	        cnic = cn;
	    }
	    public String getaddress(){
	        return address;
	    }
	    public void setaddress(String ad){
	    	address = ad;
	    }
	    
	    public void writeData() {
	    	System.out.println(getName());
	    }
	    
	    public void readData() {
	    	int test = 0;
	    }
	        
	}