package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Admin_1 {
	private JFrame frame;
	private JButton Employee_btn;
	private JButton Flavour_btn;
	private JButton Report_btn;
	private JButton Back_btn;
	
	
	public Admin_1() {

		frame = new JFrame();
		frame.setBackground(Color.BLACK);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JButton Employee_btn = new JButton("Employee");
		Employee_btn.setForeground(Color.ORANGE);
		Employee_btn.setBackground(Color.BLACK);
		Employee_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Employee_btn.setBounds(109, 48, 201, 53);
		frame.getContentPane().add(Employee_btn);
		
		JButton Flavour_btn = new JButton("Flavour");
		Flavour_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Flavour_btn.setForeground(Color.ORANGE);
		Flavour_btn.setBackground(Color.BLACK);
		Flavour_btn.setBounds(109, 142, 201, 53);
		frame.getContentPane().add(Flavour_btn);
		
		JButton Report_btn = new JButton("Report");
		Report_btn.setFont(new Font("Tahoma", Font.BOLD, 18));
		Report_btn.setForeground(Color.ORANGE);
		Report_btn.setBackground(Color.BLACK);
		Report_btn.setBounds(109, 233, 201, 53);
		frame.getContentPane().add(Report_btn);
		
		JButton Back_btn = new JButton("Back");
		Back_btn.setForeground(Color.ORANGE);
		Back_btn.setBackground(Color.BLACK);
		Back_btn.setFont(new Font("Tahoma", Font.BOLD, 11));
		Back_btn.setBounds(0, 0, 89, 23);
		
		frame.getContentPane().add(Back_btn);
		frame.setBounds(100, 100, 450, 357);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
			
		Back_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Back_btn){
	        		 frame.dispose();
	        		 Admin_0 F = new Admin_0();	 
				 }
			}
		});	
		
		Employee_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Employee_btn){
	        		 frame.dispose();
	        		 Employee_Gui F = new Employee_Gui();	 
				 }
			}
		});	
		Report_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Report_btn){
	        		 frame.dispose();
	        		 Report F = new Report();
	        		 	 
				 }
			}
		});
		Flavour_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Flavour_btn){
	        		 frame.dispose();
	        		 Flavour_Gui F = new Flavour_Gui();	 
				 }
			}
		});		
	
	
	}

}

