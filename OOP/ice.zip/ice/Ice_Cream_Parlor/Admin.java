package Ice_Cream_Parlor;

import java.io.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.Serializable;


public class Admin implements Serializable{    
    protected static ArrayList<Flavour> Flavours = new ArrayList<Flavour>();
       
    private static ArrayList<Employee> employees = new ArrayList<Employee>();
    
    public Admin(){
    	if(Flavours.size() == 0) {
    	Flavour f1 = new Flavour("Mango", 100);
    	Flavour f2 = new Flavour("Vanilla", 100);
    	Flavour f3 = new Flavour("Strawberry", 100);
    	Flavour f4 = new Flavour("Chocolate", 100);
    	Flavours.add(f1);
    	Flavours.add(f2);
    	Flavours.add(f3);
    	Flavours.add(f4);
    	}
    }
    
          
}
        

    

