package Ice_Cream_Parlor;
import java.util.*;
public class Enchanted extends Admin{
    protected Date date;
    protected int noOfScoops;
    protected String[] flavours;

    
    public Enchanted(){
        calDate();
    }

    public void calDate(){
    	date = java.util.Calendar.getInstance().getTime();
    }
    
    public void readData(){
        Scanner input = new Scanner(System.in);

        for (int j = 0; j<Flavours.size(); j++){
            System.out.println(Flavours.get(j).getName());
        }
        
    	
    	System.out.println("enter number of scoops");
    	noOfScoops = input.nextInt();
    	
    	flavours = new String[noOfScoops];    	    
    	
    	for(int i = 0; i<flavours.length; i++) {    		
    		System.out.println("enter flavour: ");
    		flavours[i] = input.next();
    		for(int j = 0; j < Flavours.size(); j++) {
    			if(Flavours.get(j).getName().equalsIgnoreCase(flavours[i])) {
    				Flavours.get(j).setNo_of_Scoops(1);
    				break;
    			};
    		}
    	}
    }
    public String toString(){
        return (" Date and time of placing order:"+date);
    }
}
