package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.io.*;
public class Flavour_st {
	private JFrame frame;
	private JButton Button1;
	private JButton backbtn;
	private JLabel Label1;
	private JLabel Label2;
	private JLabel Label3;
	private JTextField textField;
	private JTextField textField_1;
	
	public Flavour_st() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JLabel Label1 = new JLabel("Add Flavour");
		Label1.setForeground(Color.ORANGE);
		Label1.setBackground(Color.BLACK);
		Label1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		Label1.setBounds(155, 11, 130, 34);
		frame.getContentPane().add(Label1);
		
		JLabel Label2 = new JLabel("Name of Flavour");
		Label2.setFont(new Font("Tahoma", Font.BOLD, 15));
		Label2.setForeground(Color.ORANGE);
		Label2.setBounds(24, 75, 130, 39);
		frame.getContentPane().add(Label2);
		
		JLabel Label3 = new JLabel("Scoop_ID");
		Label3.setFont(new Font("Tahoma", Font.BOLD, 15));
		Label3.setForeground(Color.ORANGE);
		Label3.setBounds(24, 143, 130, 39);
		frame.getContentPane().add(Label3);
		
		textField = new JTextField();
		textField.setForeground(Color.ORANGE);
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(228, 77, 148, 39);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.ORANGE);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_1.setColumns(10);
		textField_1.setBounds(228, 143, 148, 39);
		frame.getContentPane().add(textField_1);
		
		JButton Button1 = new JButton("Enter");
		Button1.setBackground(Color.BLACK);
		Button1.setForeground(Color.ORANGE);
		Button1.setBounds(155, 227, 114, 23);
		frame.getContentPane().add(Button1);
		
		JButton backbtn = new JButton("Back");
		backbtn.setForeground(Color.ORANGE);
		backbtn.setBackground(Color.BLACK);
		backbtn.setBounds(0, 0, 77, 23);
		frame.getContentPane().add(backbtn);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 450, 302);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		
		
		backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==backbtn){
	        		 frame.dispose();
	        		 Flavour_Gui F = new Flavour_Gui();	 
				 }
			}
		});
		Button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Button1){
					 String name = textField.getText();
					 int scoopes = Integer.parseInt(textField_1.getText());
					 
					 try {
	        	            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("D:\\Lab_Assignment\\Lab_Assignment\\Flavour.dat", true)){
	        	                protected void writeStreamHeader() throws IOException {
	        	                    reset();
	        	                }
	        	            };
	        	                Flavour flv = new Flavour(name, scoopes);
	        	                output.writeObject(flv);
	        	                output.close();
	        			}
	        			catch(Exception ex) {
	        				System.out.println("Exception in Writing" + ex);
	        			}
					 
					 frame.dispose();
	        		 JOptionPane.showMessageDialog(null,"Flavour Added Successful");
	        		 Flavour_Gui F = new Flavour_Gui();	 
				 

				 
				 
				 
				 }
			}
		});	
		
		
		
		
	}
}
