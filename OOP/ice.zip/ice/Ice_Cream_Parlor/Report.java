package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import GUI.Admin_1;

public class Report {

	private JFrame frame;
	private JLabel isbscoop_label;
	private JLabel rwpscoop_label;
	private JLabel totalscoop_label;
	private JLabel Profit_label;
	private JLabel Label;
	private JLabel Label1;
	private JLabel Label2;
	private JLabel Label3;
	private JLabel Label4;
	private JButton Backbtn;
	
	public Report() {

		frame = new JFrame();
		frame.getContentPane().setForeground(Color.ORANGE);
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Report");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setForeground(Color.ORANGE);
		lblNewLabel.setBounds(179, 0, 70, 47);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ISB Scoop Sale");
		lblNewLabel_1.setForeground(Color.ORANGE);
		lblNewLabel_1.setBounds(29, 67, 82, 33);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("RWP Scoop Sale");
		lblNewLabel_1_1.setForeground(Color.ORANGE);
		lblNewLabel_1_1.setBounds(29, 118, 82, 33);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Total Scoop");
		lblNewLabel_1_2.setForeground(Color.ORANGE);
		lblNewLabel_1_2.setBounds(29, 170, 82, 33);
		frame.getContentPane().add(lblNewLabel_1_2);
		JLabel lblNewLabel_1_3 = new JLabel("Total Profit");
		lblNewLabel_1_3.setForeground(Color.ORANGE);
		lblNewLabel_1_3.setBounds(29, 224, 82, 33);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		
		
		
		isbscoop_label = new JLabel(" ");
		isbscoop_label.setFont(new Font("Tahoma", Font.BOLD, 11));
		isbscoop_label.setForeground(Color.ORANGE);
		isbscoop_label.setBounds(272, 73, 112, 20);
		frame.getContentPane().add(isbscoop_label);
		
		
		rwpscoop_label = new JLabel(" ");
		rwpscoop_label.setFont(new Font("Tahoma", Font.BOLD, 11));
		rwpscoop_label.setForeground(Color.ORANGE);
		rwpscoop_label.setBounds(272, 124, 112, 20);
		frame.getContentPane().add(rwpscoop_label);
		
		int total = 0;
		
		try {
			ObjectInputStream input=new ObjectInputStream(new FileInputStream("Isb.dat"));
		    while(input != null) {
		        SaleIsb slp = (SaleIsb) input.readObject();
		        isbscoop_label.setText(String.valueOf(slp.getIsb()));
		        total = slp.getIsb();
		    }  
		}
		catch(Exception ex) {
			System.out.println("Exception in Reading" + ex);
		}
		
		try {
			ObjectInputStream input=new ObjectInputStream(new FileInputStream("Rwp.dat"));
		    while(input != null) {
		        SaleRwp slp = (SaleRwp) input.readObject();
		        rwpscoop_label.setText(String.valueOf(slp.getRwp()));
		        total = total + slp.getRwp();
		    }  
		}
		catch(Exception ex) {
			System.out.println("Exception in Reading" + ex);
		}
		
		totalscoop_label = new JLabel(String.valueOf(total));
		totalscoop_label.setFont(new Font("Tahoma", Font.BOLD, 11));
		totalscoop_label.setForeground(Color.ORANGE);
		totalscoop_label.setBounds(272, 176, 112, 20);
		frame.getContentPane().add(totalscoop_label);
		
		Profit_label = new JLabel(String.valueOf(total * 50));
		Profit_label.setFont(new Font("Tahoma", Font.BOLD, 11));
		Profit_label.setForeground(Color.ORANGE);
		Profit_label.setBounds(272, 230, 112, 20);
		frame.getContentPane().add(Profit_label);
		
		JButton Backbtn = new JButton("Back");
		Backbtn.setForeground(Color.ORANGE);
		Backbtn.setBackground(Color.BLACK);
		Backbtn.setBounds(0, 0, 70, 23);
		frame.getContentPane().add(Backbtn);
		
		frame.setBounds(100, 100, 450, 313);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Backbtn){
	        		 frame.dispose();
	        		 Admin_0 F = new Admin_0();	 
				 }
			}
		});	
	
		
	}

}
