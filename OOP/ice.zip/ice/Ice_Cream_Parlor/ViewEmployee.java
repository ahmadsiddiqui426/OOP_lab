package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class ViewEmployee {
private JTextArea textArea;
private JButton Backbtn;
private JFrame frame;

public ViewEmployee() {
	frame = new JFrame();
	frame.getContentPane().setBackground(Color.BLACK);
	frame.setBounds(100, 100, 450, 300);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.getContentPane().setLayout(null);
	

	
	JTextArea textArea = new JTextArea();
	textArea.setForeground(Color.ORANGE);
	textArea.setBackground(Color.DARK_GRAY);
	textArea.setBounds(10, 33, 414, 217);
	frame.getContentPane().add(textArea);
	
	try {
	ObjectInputStream input=new ObjectInputStream(new FileInputStream("D:\\Lab_Assignment\\Lab_Assignment\\Emp.dat"));
    while(input != null) {
        Employee em = (Employee) input.readObject();
        textArea.setText(textArea.getText() + em.getName() + "\t" + em.getSalary() + "\r\n");
    }  
}
catch(Exception ex) {
	System.out.println("Exception in Reading" + ex);
}
	
	
	JButton Backbtn = new JButton("Back");
	Backbtn.setForeground(Color.ORANGE);
	Backbtn.setBackground(Color.BLACK);
	Backbtn.setBounds(0, -1, 89, 23);
	frame.getContentPane().add(Backbtn);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
	frame.setLocationRelativeTo(null);
	
	Backbtn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 if (e.getSource()==Backbtn){
        		 frame.dispose();
        		 Employee_Gui emp = new Employee_Gui();	 
			 }
		}
	});
	
	
	
	
	
}
}