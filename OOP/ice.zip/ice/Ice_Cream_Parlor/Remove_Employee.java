package Ice_Cream_Parlor;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Remove_Employee {
	private JFrame frame;
	private JTextField textField;
	private JLabel Label1;
	private JLabel Label3;
	private JButton Button1;
	private JButton backbtn;
	
	public Remove_Employee() {

		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JLabel Label1 = new JLabel("Remove Employee");
		Label1.setForeground(Color.ORANGE);
		Label1.setBackground(Color.BLACK);
		Label1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		Label1.setBounds(129, 11, 166, 34);
		frame.getContentPane().add(Label1);
		
		JLabel Label3 = new JLabel("Name Of Employee");
		Label3.setFont(new Font("Tahoma", Font.BOLD, 15));
		Label3.setForeground(Color.ORANGE);
		Label3.setBounds(10, 95, 153, 39);
		frame.getContentPane().add(Label3);
		
		textField = new JTextField();
		textField.setForeground(Color.ORANGE);
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(276, 95, 148, 39);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton Button1 = new JButton("Enter");
		Button1.setBackground(Color.BLACK);
		Button1.setForeground(Color.ORANGE);
		Button1.setBounds(155, 227, 114, 23);
		frame.getContentPane().add(Button1);
		
		JButton Backbtn = new JButton("Back");
		Backbtn.setForeground(Color.ORANGE);
		Backbtn.setBackground(Color.BLACK);
		Backbtn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(Backbtn);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 450, 302);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		
		
		
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Backbtn){
	        		 frame.dispose();
	        		 Employee_Gui F = new Employee_Gui();	 
	        		 
				 }
			}
		});
		Button1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 if (e.getSource()==Button1){
			ArrayList<Employee> Employees=new ArrayList<>();
			try{
	            ObjectInputStream input = new ObjectInputStream(new FileInputStream("D:\\Lab_Assignment\\Lab_Assignment\\Emp.dat"));
	            
	            while (true){
	                Employee d= (Employee) input.readObject();
	                Employees.add(d);
	                }
	                
	                
	            }
	        
	        catch (EOFException e1){
	            System.out.println("File ended");
	        }
	        catch(Exception ex){
	            ex.printStackTrace();
	            System.out.println(ex.getMessage());
	        }
			String s=Employees.get(1).getName();
//			System.out.println(Employees.get(1).getName()+" is name");
			
			
			
			
				 boolean found = false;
	    			for(int i = 0;i<Employees.size();i++){
	    				if(textField.getText().equals(Employees.get(i).getName())){
	    					found = true;
	    					Employees.remove(Employees.get(i));
	    					break;
	    				}
	    			}
	    			if (!found) {
	                	JOptionPane.showMessageDialog(null, "Record not found!");
	                }
	    			else {
	    				try{
	                        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("D:\\\\Lab_Assignment\\\\Lab_Assignment\\\\Emp.dat"));
	                        for(int j = 0; j<Employees.size(); j++){
	                            out.writeObject(Employees.get(j));
	                        }
	                        out.close();
	                        JOptionPane.showMessageDialog(null, "Record removed!");
	                    }
	                    catch (Exception ex){
	                        System.out.println(ex);
	                    }
	    				
	    			}}}
				 
			 
			 
		
	});
	
	
	
	
	
	
	
	
	}
	
	}
	
	
		

