
package Ice_Cream_Parlor;

import java.io.Serializable;

public class SaleRwp implements Serializable {
    private int Scoop_Sold_Rwp;
    
    
    public SaleRwp(int rwp) {
    	this.Scoop_Sold_Rwp = rwp;
    }
    
    public int getRwp(){
        return Scoop_Sold_Rwp;
    }
    
   
}
