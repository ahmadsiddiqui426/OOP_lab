package Ice_Cream_Parlor;

import java.io.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddEmployee_Gui {
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JLabel NameLbl;
	private JLabel SalaryLbl;
	private JLabel CnicLbl;
	private JLabel ContactLbl;
	private JLabel AddressLbl;
	private JButton Backbtn;
	private JButton Enterbtn;

	
	
	public AddEmployee_Gui() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setLayout(null);
		
		JLabel Purpose = new JLabel("Add Employee");
		Purpose.setForeground(Color.ORANGE);
		Purpose.setBackground(Color.BLACK);
		Purpose.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		Purpose.setBounds(155, 11, 130, 34);
		frame.getContentPane().add(Purpose);
		
		NameLbl = new JLabel("Name");
		NameLbl.setFont(new Font("Tahoma", Font.BOLD, 15));
		NameLbl.setForeground(Color.ORANGE);
		NameLbl.setBounds(24, 75, 130, 39);
		frame.getContentPane().add(NameLbl);
		
		JLabel SalaryLbl = new JLabel("Salary");
		SalaryLbl.setFont(new Font("Tahoma", Font.BOLD, 15));
		SalaryLbl.setForeground(Color.ORANGE);
		SalaryLbl.setBounds(24, 143, 130, 39);
		frame.getContentPane().add(SalaryLbl);
		
		JLabel ContactLbl = new JLabel("Contact");
		ContactLbl.setForeground(Color.ORANGE);
		ContactLbl.setFont(new Font("Tahoma", Font.BOLD, 15));
		ContactLbl.setBounds(24, 204, 130, 39);
		frame.getContentPane().add(ContactLbl);
		
		JLabel CnicLbl = new JLabel("Cnic");
		CnicLbl.setForeground(Color.ORANGE);
		CnicLbl.setFont(new Font("Tahoma", Font.BOLD, 15));
		CnicLbl.setBounds(24, 260, 130, 39);
		frame.getContentPane().add(CnicLbl);
		
		JLabel AddressLbl = new JLabel("Address");
		AddressLbl.setForeground(Color.ORANGE);
		AddressLbl.setFont(new Font("Tahoma", Font.BOLD, 15));
		AddressLbl.setBounds(24, 326, 130, 39);
		frame.getContentPane().add(AddressLbl);
		
		textField = new JTextField();
		textField.setForeground(Color.ORANGE);
		textField.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField.setBounds(228, 77, 148, 39);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.ORANGE);
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_1.setColumns(10);
		textField_1.setBounds(228, 143, 148, 39);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setForeground(Color.ORANGE);
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_2.setColumns(10);
		textField_2.setBounds(228, 204, 148, 39);
		frame.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setForeground(Color.ORANGE);
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_3.setColumns(10);
		textField_3.setBounds(228, 260, 148, 39);
		frame.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setForeground(Color.ORANGE);
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		textField_4.setColumns(10);
		textField_4.setBounds(228, 326, 148, 39);
		frame.getContentPane().add(textField_4);
		frame.setBackground(Color.BLACK);
		frame.setBounds(100, 100, 427, 462);
		
		JButton Enterbtn = new JButton("Enter");
		Enterbtn.setBackground(Color.BLACK);
		Enterbtn.setForeground(Color.ORANGE);
		Enterbtn.setBounds(153, 389, 114, 23);
		frame.getContentPane().add(Enterbtn);
		
		Backbtn = new JButton("Back");
		Backbtn.setForeground(Color.ORANGE);
		Backbtn.setBackground(Color.BLACK);

		Backbtn.setBounds(0, 0, 89, 23);
		frame.getContentPane().add(Backbtn);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		Backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Backbtn){
	        		 frame.dispose();
	        		 Employee_Gui F = new Employee_Gui();	 
	        		 
				 }
			}
			
		});
		Enterbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource()==Enterbtn){
	        			String Name = textField.getText();				
	        			int salary = Integer.parseInt(textField_1.getText());		
	        			String contact = textField_2.getText();				
	        			String cnic = textField_3.getText(); 			
	        			String address = textField_4.getText();			
	        		//	Employee = new Employee(Name, salary, contact, cnic, address); // Creating Employee Class Object
	        			try {
	        	            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("D:\\Lab_Assignment\\Lab_Assignment\\Emp.dat", true)){
	        	                protected void writeStreamHeader() throws IOException {
	        	                    reset();
	        	                }
	        	            };
	        	                Employee emp = new Employee(Name, salary, contact, cnic, address);
	        	                output.writeObject(emp);
	        	                output.close();
	        			}
	        			catch(Exception ex) {
	        				System.out.println("Exception in Writing" + ex);
	        			}
	        			
	        			JOptionPane.showMessageDialog(null, "Employee Added Successfully");
	        			frame.dispose();
	        			Employee_Gui f = new Employee_Gui();
	        		 
				 }
			}
			
		});
		
	
	}
}

